﻿Yükleme Kodları Termux

$ apt update

$ apt upgrade

$ apt install python

$ apt install git

$ git clone https://github.com/Myyepz/NewSB

$ cd NewSB

$ python -m pip install -r requirements.txt

$ python3 sby.py

------------------------------

Installation for VPS

$ git clone https://github.com/erengitti/erengitti

$ cd erengitti

$ python3 -m pip install -r requirements.txt

$ python3 sby.py

------------------------------

Rework By ⭐  Ereɳ Gitti  ⭐ 